﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessing
{
    public class LearningToSki : IRule
    {
        public string createRule()
        {
            return "Add a video to the Packing Slip";
        }
    }
}
