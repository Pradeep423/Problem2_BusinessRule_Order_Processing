﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessing
{
    public class ActivateMembership : IPayment
    {
        public string MakePayment()
        {
            return "activate the membership";
        }
    }
}
