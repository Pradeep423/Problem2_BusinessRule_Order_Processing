﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessing
{
    public class CommissionPayment : IPayment
    {
        public string MakePayment()
        {
            return "generating Commission Payment";
        }
    }
}
