﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessing
{
    public class BookProduct : IRule
    {
        protected IPayment _payment;

        public BookProduct(IPayment payment)
        {
            _payment = payment;
        }
        public string createRule()
        {
            return _payment.MakePayment();
        }
    }
}
