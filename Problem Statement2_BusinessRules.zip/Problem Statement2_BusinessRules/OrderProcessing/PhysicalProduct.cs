﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessing
{
    public class PhysicalProduct : IRule
    {
        protected IPayment _payment;

        public PhysicalProduct(IPayment payment)
        {
            _payment = payment;
        }
        public string createRule()
        {
            return _payment.MakePayment();
        }
    }
}
