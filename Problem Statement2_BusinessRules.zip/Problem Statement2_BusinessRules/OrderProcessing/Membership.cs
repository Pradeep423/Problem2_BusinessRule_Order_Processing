﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessing
{
    public class Membership : IRule, IEmail
    {
        protected IPayment _payment;

        public Membership(IPayment payment)
        {
            _payment = payment;
        }

        public Membership()
        {

        }
        public string createRule()
        {
            return _payment.MakePayment();
        }

        public string SendEmail()
        {
            return "activation/upgrade has been done";
        }
    }
}
