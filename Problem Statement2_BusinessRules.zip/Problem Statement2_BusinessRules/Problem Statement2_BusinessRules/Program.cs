﻿using System;
using OrderProcessing;

namespace Problem_Statement2_BusinessRules
{
    public class Program
    {
        static void Main(string[] args)
        {
            bool showMenu = true;
            while (showMenu)
            {                
                Console.WriteLine("Choose an option:");
                Console.WriteLine("1) physical product");
                Console.WriteLine("2) book");
                Console.WriteLine("3) membership");
                Console.WriteLine("4) upgrade to a membership");
                Console.WriteLine("5) membership or upgrade");
                Console.WriteLine("6) learning to ski");
                Console.WriteLine("7) physical product or book");
                Console.WriteLine("8) Exit");
                Console.Write("\r\nSelect an option: ");
                string str = Console.ReadLine();
                showMenu = MainMenu(str);
            }
            Console.ReadLine();
        }
     
        public static bool MainMenu(string str)
        {           
            switch (str.ToLower())
            {
                case "1":
                    PhysicalProduct pProduct = new PhysicalProduct(new PackingSlip());
                    Console.WriteLine(pProduct.createRule());
                    return true;
                case "2":
                    BookProduct book = new BookProduct(new DuplicatePackingSlip());
                    Console.WriteLine(book.createRule());
                    return true;

                case "3":
                    Membership membership = new Membership(new ActivateMembership());
                    Console.WriteLine(membership.createRule());
                    return true;
                case "4":
                    Membership memberUpgrade = new Membership(new UpgradeMembership());
                    Console.WriteLine(memberUpgrade.createRule());
                    return true;

                case "5":
                    Membership memberUpgradeEmail = new Membership();
                    Console.WriteLine(memberUpgradeEmail.SendEmail());
                    return true;
                case "6":
                    LearningToSki learnski = new LearningToSki();
                    Console.WriteLine(learnski.createRule());
                    return true;
                case "7":
                    CommissionPayment productBook = new CommissionPayment();
                    Console.WriteLine(productBook.MakePayment());
                    return true;
                case "8":
                    return false;
                default:
                    Console.WriteLine("Please enter the correct option");
                    return true;
            }
        }       
    }
}
