﻿using System;

namespace OrderProcessing.Tests
{
    public class OrderProcessingTests
    {
    }
}
