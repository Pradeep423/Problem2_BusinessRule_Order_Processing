﻿using NUnit.Framework;
using System;
using Problem_Statement2_BusinessRules;

namespace OrderProcessing.Tests
{
    [TestFixture]
    public class OrderProcessingTests
    {

        //Red Phase

        //[Test]
        //public void SampleTest()
        //{
        //    //Assert.Pass();

        //    //Arrange
        //    string input = "1";

        //    //Act
        //    bool output = Program.MainMenu(input);

        //    //Assert
        //}

            //Green Phase
        [Test]
        public void PhysicalPayment()
        {
            //Arrange
            string input = "1";

            //Act
            bool ouput = Program.MainMenu(input);

            //Assert
            Assert.AreEqual(true, ouput);
            //bool output = Program.MainMenu(values);
        }

        //Refactor

        [Test]
        public void PhysicalPayment([Values("1")] string values)
        {
            bool output = Program.MainMenu(values);
        }

        [Test]
        public void BookPayment([Values("2")] string values)
        {
            bool output = Program.MainMenu(values);

        }

        [Test]
        public void MembershipPayment([Values("3")] string values)
        {
            bool output = Program.MainMenu(values);

        }

        [Test]
        public void MemberShipUpgrade([Values("4")] string values)
        {
            bool output = Program.MainMenu(values);

        }

        [Test]
        public void MemberShipOrUpgradePayment([Values("5")] string values)
        {
            bool output = Program.MainMenu(values);

        }

        [Test]
        public void LearningToSkiPayment([Values("6")] string values)
        {
            bool output = Program.MainMenu(values);

        }

        [Test]
        public void PhysicalProductOrBook([Values("7")] string values)
        {
            bool output = Program.MainMenu(values);

        }

        [Test]
        public void ExitPayment([Values("8")] string values)
        {
            bool output = Program.MainMenu(values);

        }


        [Test]
        public void SampleTest([Values("1","2","3","4","5","6","7","8")] string values)
        {
            bool output = Program.MainMenu(values);

        }
    }
}
